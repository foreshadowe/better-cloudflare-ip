with open('data2.txt','a') as f:
    for i in range(0,256):
        for j in range(0,256):
            f.write('104.19.'+str(i)+'.'+str(j)+'\n')
f.close()
